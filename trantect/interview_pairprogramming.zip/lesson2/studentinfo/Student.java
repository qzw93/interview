package studentinfo;

class Student {
   private String name;

   Student(String name) {
      this.name = name;
   }

   String getName() {
      return name;
   }
}